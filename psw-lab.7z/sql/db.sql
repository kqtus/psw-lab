DROP DATABASE IF EXISTS psw_db;

CREATE DATABASE psw_db;

USE psw_db;

CREATE TABLE psw_db
(
   ID int NOT NULL AUTO_INCREMENT PRIMARY KEY,
   id
   ...
   ...
   ...
);

INSERT INTO nazwa_tabeli (...) VALUES (...);
INSERT INTO nazwa_tabeli (...) VALUES (...);
INSERT INTO nazwa_tabeli (...) VALUES (...);
