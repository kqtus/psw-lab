<!DOCTYPE html>
<html>
<?php
    $name = 'Marek';

?>
    <head>
        <meta charset="utf-8">
        <title>
            Simple PHP doc
        </title>
    </head>
    <body>
        <h1>
            <?php 
            print("Welcome to PHP, $name!"); 
            ?>
        </h1>
    </body>
</html>